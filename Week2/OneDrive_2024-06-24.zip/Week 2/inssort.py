
import time

a = list(map(int, input().split()))

n = len(a)

st = time.process_time()

# write the insertion sort code into this segment


    
et = time.process_time()

print(a)
print(et-st)
